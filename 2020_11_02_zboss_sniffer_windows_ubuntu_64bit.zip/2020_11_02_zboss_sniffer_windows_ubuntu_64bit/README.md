# ZB Sniffer Package Rev. 2.0

The ZB sniffer package here provided allows to use Texas CC13xx/CC25xx to capture Zigbee packets for 2.4GHz, GB/EU/NA Sub-GHz,
depending on which board is used (see 'Features' section bellow). A GUI/console application allows to select Page and Channel for which
capture shall be performed and starts live capture view with Wireshark.

From this point, 'sniffer_target' refers to the binary executing in Texas boards and 'sniffer_host' refers to either GUI or Console
applications running at the machine who launches them.

Also, at this README.md level, we find package's root. From this point, we use 'root/' to identify it.

## Contents
- Features.
- Requirements.
- Package structure.
- Known issues.


## Features

The binaries for Texas boards within this package allow to capture packets according to the following:
- CC25xx: 2.4 GHz: Page 0.
- CC1350: only GB Sub-GHz: Pages 28-31.
- CC1352R1: 2.4GHz and GB Sub-GHz: Pages 0,28-31.
- CC1352P1: 2.4GHz and GB Sub-GHz: Pages 0,28-31.
- CC1352P2: 2.4GHz and GB/EU/NA Sub-GHz: 0,22-31.

Any of the above devices, once flashed with zb_sniffer binary, will start to display its operational state by the means of a blinking
LED (gree LED). As soon as capture starts, triggered by Console/GUI applications, the exact same green LED changes to a constant ON
state.

Based on this, the GUI/console application provides a mean to launch Wireshark within supported Page/Channel supported by each
board.

Moreover, a single GUI application instance allows to launch multiple devices, each capturing packets for the same or different
Page/Channel combinations. The same may be performed by launching multiple instances of Console application.

Diagnostic information may be stored into a 'log.txt' file.

Also, captures launched by both Console and GUI allow to save Wireshark's current capture at any given time for offline analysis.

Some features are only supported by GUI application, like the possibility to Pause/Resume, Stop/Resume and change Page/Channel for each
independent device, without the need to reset/relaunch either sniffer_target or sniffer_host. Wireshark's interface may also be
'cleaned' at any point due to the support for its 'Restart' button.


## Requirements

Different combinations of sniffer_target and sniffer_host imply different requirements. In summary, sniffer_host may be ran both in
Linux and Windows OS (tested in Ubuntu 20.04 LTS and Windows 10 environments), exception being Console application (Linux support only).

Regarding sniffer_target, no constraints apply (other than the obvious: usage of supported boards mentioned above).

### Software requirements
#### General
- Wireshark (tested with version 3.2.3).
- TI utilities: Texas Uniflash and XDS emupack.

> **Note:**
> Wireshark: https://www.wireshark.org/download.html
> Uniflash: https://www.ti.com/tool/UNIFLASH
> XDS emupack: https://software-dl.ti.com/ccs/esd/documents/xdsdebugprobes/emu_xds_software_package_download.html
> Useful guide for TI utilities: https://software-dl.ti.com/ccs/esd/uniflash/docs/v5_0/quick_start_guide/uniflash_quick_start_guide.html

#### sniffer_host GUI
- OS: tested in Windows 10 and Linux (tested with Ubuntu 20.04 LTS, please see note bellow).

- GUI compiled with:
  - Windows 10: MinGW 7.3.0 64-bit, using Qt 5.12.9. User does NOT require any of these!
  - Ubuntu 20.04 LTS: gcc 9.3.0, qmake 3.1 and Qt 5.12.8. If your system has other versions, it might be needed to build it locally.

> **Note Linux:** The provided sniffer_host GUI is a Qt5 application and was compiled with gcc 9.3.0. You may check if your system has all the
> required dependencies by prompting:
> ```$ ldd ./zboss_sniffer```.
> See the package with sources, and within `root/zb_sniffer_src/zb_sniffer_host/gui/README.md` find instructions on how to build sniffer_host GUI,
> in case of difficulties with setting up all the missing dependencies displayed by the command above.

#### sniffer_host Console
- OS: Linux only (tested with Ubuntu 20.04 LTS, please see note bellow).

> **Note:** The provided sniffer_host Console was compiled with gcc 9.3.0. You may check if your system has all the required
> dependencies by prompting:
> ```$ ldd ./zboss_sniffer```.
> See the package with sources, and within `root/zb_sniffer_src/zb_sniffer_host/console/README.md` find instructions on how to build sniffer_host
> console, in case of difficulties with setting up all the missing dependencies displayed by the command above.

### Hardware requirements
- Having in mind the aforementioned constraints for each target, at least 1 of the following is needed:
- CC25xx.
- CC1350.
- CC1352R1.
- CC1352P1.
- CC1352P2.


## Package structure

The ZB sniffer package here provided is mainly divided in:
- binaries for target devices and GUI/console.

Every directory comprises a README.md file with details/notes for the underlying context: flash, configure, how to use, etc,
when such context applies. This way, we provide self contained 'guide' for the scope of the directory.

The overall package's structure is as follows:
```
root/
|
└───README.md
└───zb_sniffer_bin/
     └───zb_sniffer_host/
     |    └───console/
     |    |    └───README.md
     |    |    └───zboss_sniffer
     |    └───gui/
     |         └───(binary for Linux and Windows + Windows dependencies)
     └───zb_sniffer_target/
          └───README.md
          └───CC1350 SubGHz/
          |    └───zb_sniffer_cc1350.hex
          └───CC1352P1_dualband/
          |    └───sniffer_cc1352.hex
          └───CC1352P2_dualband/
          |    └───zboss_sniffer.hex
          └───CC1352R1_dualband/
          |    └───zb_sniffer_cc1352.hex
          └───CC2531 USB dongle/
               └───zboss_sniffer.hex
```


## Known issues

### CC1352P1 Rev.A fails to capture the following page/channel
    - page 0 channel 11
    - page 0 channel 24
    - page 0 channel 26
    - Sub-GHz page 28 channel 24
    - Sub-GHz page 29 channel 62
    - Sub-GHz page 30 channel 61
    - Sub-GHz page 31 channel 26

### CC1352P1 Rev.B fails to capture the following page/channel
    - Sub-GHz page 28 channel 24
    - Sub-GHz page 29 channel 62
    - Sub-GHz page 30 channel 61

### CC1352R1 fails to capture the following page/channel
    - Sub-GHz page 29 channel 62
    - Sub-GHz page 30 channel 61

### CC2530 fails to capture the following page/channel
    - page 0 channel 
    - Sub-GHz page 31 channel 26

### Flashing a Texas CC13xx while sniffer board is running

One of the use cases for sniffer console/GUI is to have:
- a Texas CC13xx board running sniffer binary,
- a Texas CC13xx running a ZBOSS application.

Eventually, you will change the firmware running on the non-sniffer board. Flashing a Texas CC13xx board while other Texas CC13xx is
running sniffer binary, will break the data exchange between the host (your machine) and target (CC13xx).

This happens in case you:
- have more than 1 Texas CC13xx boards plugged to the same machine,
- use Uniflash utility to flash them.

Even though Uniflash allows to create a session and select which board to flash, you may notice all your devices blink as soon as you
flash the device under current Uniflash's session. Uniflash tries to identify the current session's board before flashing it, inquiring
all available ones. This breaks the data exchange between the sniffer board and the host running sniffer console/GUI.

Easiest workaround is to press reset button on the sniffer board and re-open sniffer console/GUI after flashing another Texas CC13xx
board with new firmware.

### Pressing Wireshark's restart button

In case you started a capture and you press wireshark's restart button, the reset button on sniffer board has to be pressed. Please
consider using sniffer GUI if this is a major issue.
