# Sniffer binaries


## Supported Pages per Device.
- CC25xx: 2.4 GHz: Page 0.
- CC1350: only GB Sub-GHz: Pages 28-31.
- CC1352R1: 2.4GHz and GB Sub-GHz: Pages 0,28-31. 
- CC1352P1: 2.4GHz and GB Sub-GHz: Pages 0,28-31.
- CC1352P2: 2.4GHz and GB Sub-GHz: 0,22-31.


## How to Flash - example for Texas CC13xx 

Using Uniflash, we can (among other operations) erase flash contents and flash the devices with the binaries here provided.
See root/README.md for requirements before trying to perform operations described bellow.

> **Note:** Besides the links with utilities, consider reading the 'Useful guide for TI utilities'.
> Uniflash: https://www.ti.com/tool/UNIFLASH
> XDS emupack: https://software-dl.ti.com/ccs/esd/documents/xdsdebugprobes/emu_xds_software_package_download.html
> Useful guide for TI utilities: https://software-dl.ti.com/ccs/esd/uniflash/docs/v5_0/quick_start_guide/uniflash_quick_start_guide.html


### How to erase flash
Plug the device to the PC. Launch Uniflash and select the device by pressing "start" button. Afterwards, click "Settings & Utilities"
on the left panel. Look for "Erase Entire Flash" and click on it.
Console's output will be displayed on bottom panel, indicating success of fail of the operation.


### How to flash
Using the Uniflash utility, we simply need to plug Texas CC13xx to the PC and select it within Uniflash's GUI. Afterwards, within 
Uniflash, click "+" (plus) button and browse into the same directory as this file.

To conclude flashing  process, click "Load Image" button and check message on bottom. A message as
```[SUCCESS] Program Load completed successfully.``` is a good indicator. Press the texas CC13xx reset button and a green LED should
start to blink.

Time to launch the sniffer console/GUI provided within this package. 
