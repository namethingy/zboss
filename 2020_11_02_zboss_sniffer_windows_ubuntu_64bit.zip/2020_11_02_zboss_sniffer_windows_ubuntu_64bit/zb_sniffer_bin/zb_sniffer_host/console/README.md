# Sniffer console

## Launch sniffer console along with wireshark

> **Hint:** You may check help instructions by prompting ```$ ./zboss_sniffer --h```

This is the template for launching sniffer console and wireshark. All it needs is you to specify the port where the sniffer board is
connected at, plus the page and channel the capture shall be performed.

```
$ ./zboss_sniffer -i /dev/yourDevHere P C - |wireshark -k -i -
```

To log the output into a file:

```
$ ./zboss_sniffer -i /dev/yourDevHere P C - >> trafficlog.pcap
```


Run the command above, substituting '***yourDevHere***' by the port your sniffer hardware is at.
Also, susbtitute '***P***' and '***C***' for the desired Page and Channel you want sniffer board to capture packets.

The sniffer's LED will stop blinking, changing to constant ON state, and wireshark window will be displayed. Capture has started!

> **Hint:** You may check in which port your device is by prompting ```$ ls /dev/ | grep ttyACM* ``` before and after connecting your
> board to the host machine. The new entries displayed after connecting the board, indicate which port you can use. In case of Texas
> CC13xx, two new entries will be present: use the one with the lowest number.

> **Note!:** Check the other options to pass using ```$ ./zboss_sniffer --h```. For instance ``` -d ``` provides diagnostic output in
> text form to log.txt file. It may be combined with template given above:
> ```$ ./zboss_sniffer -d -i /dev/yourDevHere P C - |wireshark -k -i -```

> **Note!:** if running the console fails, then check **zboss_sniffer permissions**.
> Solve it by issuing ```$ chmod +x zboss_sniffer```
